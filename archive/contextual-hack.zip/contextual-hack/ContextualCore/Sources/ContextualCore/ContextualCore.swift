import Foundation

/// Namespace marker for the core module.
public enum ContextualCore {}
