//
//  StardustTraceView.swift
//  KilroyWalkApp
//
//  Magic trace animation
//

import SwiftUI

struct StardustTraceView: View {

    @State private var animate = false

    var body: some View {
        Circle()
            .trim(from: 0.0, to: animate ? 1.0 : 0.0)
            .stroke(
                ContextualStyle.stardust,
                style: StrokeStyle(
                    lineWidth: 1.5,
                    lineCap: .round
                )
            )
            .blur(radius: 1)
            .rotationEffect(.degrees(-90))
            .animation(
                .easeOut(duration: ContextualStyle.traceDuration),
                value: animate
            )
            .onAppear {
                animate = true
            }
    }
}
