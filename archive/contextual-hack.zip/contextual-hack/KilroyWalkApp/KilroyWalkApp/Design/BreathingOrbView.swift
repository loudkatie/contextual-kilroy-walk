//
//  BreathingOrbView.swift
//  KilroyWalkApp
//
//  The living orb
//

import SwiftUI

struct BreathingOrbView: View {

    @State private var isBreathing = false

    var body: some View {
        ZStack {

            // Core orb gradient
            Circle()
                .fill(
                    LinearGradient(
                        colors: [
                            ContextualStyle.orbLilac,
                            ContextualStyle.orbBlue,
                            ContextualStyle.orbMint,
                            ContextualStyle.orbPeach
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .scaleEffect(isBreathing ? 1.03 : 0.97)
                .blur(radius: 0.2)
                .animation(
                    ContextualStyle.breatheEase.repeatForever(autoreverses: true),
                    value: isBreathing
                )

            // Halo edge
            Circle()
                .stroke(
                    ContextualStyle.haloWhite,
                    lineWidth: 2
                )
                .blur(radius: 1.5)
                .scaleEffect(isBreathing ? 1.04 : 0.98)
                .animation(
                    ContextualStyle.breatheEase.repeatForever(autoreverses: true),
                    value: isBreathing
                )
        }
        .onAppear {
            isBreathing = true
        }
    }
}
