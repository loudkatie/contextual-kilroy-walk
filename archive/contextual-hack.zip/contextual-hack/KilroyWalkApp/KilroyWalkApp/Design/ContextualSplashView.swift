//
//  ContextualSplashView.swift
//  KilroyWalkApp
//
//  Splash experience
//

import SwiftUI

struct ContextualSplashView: View {

    var body: some View {
        ZStack {

            ContextualStyle.background
                .ignoresSafeArea()

            VStack(spacing: 48) {

                // Wordmark
                Text("CONTEXTUAL")
                    .font(ContextualStyle.wordmarkFont(size: 24))
                    .tracking(ContextualStyle.wordmarkTracking)
                    .foregroundStyle(ContextualStyle.graphite.opacity(0.85))

                ZStack {

                    StardustTraceView()
                        .frame(width: 240, height: 240)

                    BreathingOrbView()
                        .frame(width: 220, height: 220)
                }
            }
        }
    }
}
