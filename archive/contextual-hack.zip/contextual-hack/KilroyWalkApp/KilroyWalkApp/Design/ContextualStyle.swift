//
//  ContextualStyle.swift
//  KilroyWalkApp
//
//  Design system v0 — locked for initial build
//

import SwiftUI

enum ContextualStyle {

    // MARK: - Backgrounds

    /// Soft lavender fog used for most surfaces
    static let background = Color(
        red: 0.965,
        green: 0.945,
        blue: 0.985
    )

    /// Dark graphite used sparingly (icons, contrast states)
    static let graphite = Color(
        red: 0.52,
        green: 0.52,
        blue: 0.58
    )

    // MARK: - Light & Stardust

    static let haloWhite = Color.white.opacity(0.90)

    static let stardust = Color(
        red: 0.985,
        green: 0.955,
        blue: 0.885
    ).opacity(0.95)

    // MARK: - Orb (iridescent anchors)

    static let orbLilac = Color(red: 0.86, green: 0.82, blue: 0.95)
    static let orbBlue   = Color(red: 0.78, green: 0.86, blue: 0.98)
    static let orbMint   = Color(red: 0.80, green: 0.96, blue: 0.93)
    static let orbPeach  = Color(red: 0.99, green: 0.88, blue: 0.86)

    // MARK: - Typography

    /// We standardize size & tracking only. Font family stays system.
    static func wordmarkFont(size: CGFloat) -> Font {
        .system(size: size, weight: .light, design: .default)
    }

    /// Wide, airy tracking — never shouty
    static let wordmarkTracking: CGFloat = 0.28

    // MARK: - Motion (v0 lock)

    /// Orb breathing duration (full inhale + exhale)
    static let breathingDuration: Double = 6.8

    /// Sparkle / trace animation duration
    static let traceDuration: Double = 2.4

    /// Global easing curve
    static let breatheEase: Animation = .easeInOut(duration: breathingDuration)
}
